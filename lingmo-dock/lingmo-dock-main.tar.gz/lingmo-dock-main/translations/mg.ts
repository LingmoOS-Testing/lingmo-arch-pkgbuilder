<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="mg">
<context>
    <name>AppItem</name>
    <message>
        <location filename="../qml/AppItem.qml" line="73"/>
        <source>Open</source>
        <translation>Voahay</translation>
    </message>
    <message>
        <location filename="../qml/AppItem.qml" line="85"/>
        <source>Unpin</source>
        <translation>Tsoahina eto</translation>
    </message>
    <message>
        <location filename="../qml/AppItem.qml" line="85"/>
        <source>Pin</source>
        <translation>Apetaka eto</translation>
    </message>
    <message>
        <location filename="../qml/AppItem.qml" line="94"/>
        <source>Close window</source>
        <translation>Hidio ity fisokafana ity</translation>
    </message>
    <message>
        <location filename="../qml/AppItem.qml" line="95"/>
        <source>Close %1 windows</source>
        <translation>Hidio ny %1 amin&apos;ireto fisokafana ireto</translation>
    </message>
</context>
<context>
    <name>ApplicationModel</name>
    <message>
        <location filename="../src/applicationmodel.cpp" line="285"/>
        <source>Launcher</source>
        <translation>Mpampandeha</translation>
    </message>
</context>
<context>
    <name>main</name>
    <message>
        <location filename="../qml/main.qml" line="114"/>
        <source>Trash</source>
        <translation>Tsy ilaina</translation>
    </message>
    <message>
        <location filename="../qml/main.qml" line="124"/>
        <source>Open</source>
        <translation>Sokafana</translation>
    </message>
    <message>
        <location filename="../qml/main.qml" line="129"/>
        <source>Empty Trash</source>
        <translation>Tsy misy n&apos;inona n&apos;inona</translation>
    </message>
</context>
</TS>
