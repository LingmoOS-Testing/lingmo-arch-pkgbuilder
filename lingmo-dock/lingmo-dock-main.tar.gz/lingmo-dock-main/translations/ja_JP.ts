<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ja">
<context>
    <name>AppItem</name>
    <message>
        <location filename="../qml/AppItem.qml" line="73"/>
        <source>Open</source>
        <translation>開く</translation>
    </message>
    <message>
        <location filename="../qml/AppItem.qml" line="85"/>
        <source>Unpin</source>
        <translation>解除</translation>
    </message>
    <message>
        <location filename="../qml/AppItem.qml" line="85"/>
        <source>Pin</source>
        <translation>固定</translation>
    </message>
    <message>
        <location filename="../qml/AppItem.qml" line="94"/>
        <source>Close window</source>
        <translation>ウィンドウを閉じる</translation>
    </message>
    <message>
        <location filename="../qml/AppItem.qml" line="95"/>
        <source>Close %1 windows</source>
        <translation>%1つのウィンドウを閉じる</translation>
    </message>
</context>
<context>
    <name>ApplicationModel</name>
    <message>
        <location filename="../src/applicationmodel.cpp" line="285"/>
        <source>Launcher</source>
        <translation>ランチャー</translation>
    </message>
</context>
<context>
    <name>main</name>
    <message>
        <location filename="../qml/main.qml" line="114"/>
        <source>Trash</source>
        <translation>ゴミ箱</translation>
    </message>
    <message>
        <location filename="../qml/main.qml" line="124"/>
        <source>Open</source>
        <translation>開く</translation>
    </message>
    <message>
        <location filename="../qml/main.qml" line="129"/>
        <source>Empty Trash</source>
        <translation>ごみ箱を空にする</translation>
    </message>
</context>
</TS>
