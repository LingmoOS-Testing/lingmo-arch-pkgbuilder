<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ta">
<context>
    <name>AppItem</name>
    <message>
        <location filename="../qml/AppItem.qml" line="73"/>
        <source>Open</source>
        <translation>திற</translation>
    </message>
    <message>
        <location filename="../qml/AppItem.qml" line="85"/>
        <source>Unpin</source>
        <translation>சேமித்ததை நீக்கு</translation>
    </message>
    <message>
        <location filename="../qml/AppItem.qml" line="85"/>
        <source>Pin</source>
        <translation>சேமி</translation>
    </message>
    <message>
        <location filename="../qml/AppItem.qml" line="94"/>
        <source>Close window</source>
        <translation>பயன்பாட்டை மூடு</translation>
    </message>
    <message>
        <location filename="../qml/AppItem.qml" line="95"/>
        <source>Close %1 windows</source>
        <translation>பயன்பாடுகளை %1 மூடு</translation>
    </message>
</context>
<context>
    <name>ApplicationModel</name>
    <message>
        <location filename="../src/applicationmodel.cpp" line="285"/>
        <source>Launcher</source>
        <translation>துவக்கி</translation>
    </message>
</context>
<context>
    <name>main</name>
    <message>
        <location filename="../qml/main.qml" line="114"/>
        <source>Trash</source>
        <translation>குப்பை</translation>
    </message>
    <message>
        <location filename="../qml/main.qml" line="124"/>
        <source>Open</source>
        <translation>திற</translation>
    </message>
    <message>
        <location filename="../qml/main.qml" line="129"/>
        <source>Empty Trash</source>
        <translation>குப்பையை அழி</translation>
    </message>
</context>
</TS>
