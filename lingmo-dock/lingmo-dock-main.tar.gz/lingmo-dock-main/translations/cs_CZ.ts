<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="cs">
<context>
    <name>AppItem</name>
    <message>
        <location filename="../qml/AppItem.qml" line="73"/>
        <source>Open</source>
        <translation>Otevřít</translation>
    </message>
    <message>
        <location filename="../qml/AppItem.qml" line="85"/>
        <source>Unpin</source>
        <translation>Odepnout</translation>
    </message>
    <message>
        <location filename="../qml/AppItem.qml" line="85"/>
        <source>Pin</source>
        <translation>Připnout</translation>
    </message>
    <message>
        <location filename="../qml/AppItem.qml" line="94"/>
        <source>Close window</source>
        <translation>Zavřít okno</translation>
    </message>
    <message>
        <location filename="../qml/AppItem.qml" line="95"/>
        <source>Close %1 windows</source>
        <translation>Zavřít %1 okna</translation>
    </message>
</context>
<context>
    <name>ApplicationModel</name>
    <message>
        <location filename="../src/applicationmodel.cpp" line="285"/>
        <source>Launcher</source>
        <translation>Přehled aplikací</translation>
    </message>
</context>
<context>
    <name>main</name>
    <message>
        <location filename="../qml/main.qml" line="114"/>
        <source>Trash</source>
        <translation>Koš</translation>
    </message>
    <message>
        <location filename="../qml/main.qml" line="124"/>
        <source>Open</source>
        <translation>Otevřít</translation>
    </message>
    <message>
        <location filename="../qml/main.qml" line="129"/>
        <source>Empty Trash</source>
        <translation>Vysypat koš</translation>
    </message>
</context>
</TS>
