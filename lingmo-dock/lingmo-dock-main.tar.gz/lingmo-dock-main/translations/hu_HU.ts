<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="hu">
<context>
    <name>AppItem</name>
    <message>
        <location filename="../qml/AppItem.qml" line="73"/>
        <source>Open</source>
        <translation>Megnyitás</translation>
    </message>
    <message>
        <location filename="../qml/AppItem.qml" line="85"/>
        <source>Unpin</source>
        <translation>Levétel</translation>
    </message>
    <message>
        <location filename="../qml/AppItem.qml" line="85"/>
        <source>Pin</source>
        <translation>Kitűzés</translation>
    </message>
    <message>
        <location filename="../qml/AppItem.qml" line="94"/>
        <source>Close window</source>
        <translation>Ablak bezárása</translation>
    </message>
    <message>
        <location filename="../qml/AppItem.qml" line="95"/>
        <source>Close %1 windows</source>
        <translation>%1 ablak bezárása</translation>
    </message>
</context>
<context>
    <name>ApplicationModel</name>
    <message>
        <location filename="../src/applicationmodel.cpp" line="285"/>
        <source>Launcher</source>
        <translation>Indítópult</translation>
    </message>
</context>
<context>
    <name>main</name>
    <message>
        <location filename="../qml/main.qml" line="114"/>
        <source>Trash</source>
        <translation>Kuka</translation>
    </message>
    <message>
        <location filename="../qml/main.qml" line="124"/>
        <source>Open</source>
        <translation>Megnyitás</translation>
    </message>
    <message>
        <location filename="../qml/main.qml" line="129"/>
        <source>Empty Trash</source>
        <translation>Kuka ürítése</translation>
    </message>
</context>
</TS>
